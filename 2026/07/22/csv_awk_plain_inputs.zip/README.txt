csv.awk validation corpus

- Each .csv file is one independent stdin input.
- Only default comma delimiter and double-quote semantics were retained.
- Custom delimiters, escapechar, QUOTE_* modes, strict-only assertions, and Sniffer cases were excluded.
- Expected outputs are intentionally omitted.

Run all:
  for f in *.csv; do echo "== $f =="; awk -f ../csv.awk "$f"; done
